// ====== CONFIGURAÇÃO DA URNA (edite aqui) ======
// Para mudar o número de um candidato, troque o número entre aspas (ex.: "11" -> "45").
// O número deve ter a mesma quantidade de dígitos definida em DIGITOS.
var CARGO = "Presidente do Grêmio";
var DIGITOS = 2;
var SENHA = "1234";
var CANDIDATOS = {
  "11": {nome:"Ana Souza",  partido:"Partido Estrela", cor:"#4a6fa5"},
  "22": {nome:"Bruno Lima", partido:"Partido Sol",     cor:"#c47a1e"}
};
// ===============================================
